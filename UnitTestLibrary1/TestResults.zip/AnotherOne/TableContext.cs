﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace AnotherOne
{
    using System;
    using System.Collections.Generic;

    public class TableContext
    {

        public string Fname { get; set; }
        public string Lname { get; set; }
        public int Id { get; set; }
        public int Grade { get; set; }
        public string Exam { get; set; }

        public TableContext()
        { 
           
        }
       
    }


}
