﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace UILayer
{
    using System;
    using System.Collections.Generic;

    public class Table
    {
        public string Fname;
        public string Lname;
        public string Grade;
        public int Id;
       

        public Table()
        { 
   
           
        }
       
    }


}
