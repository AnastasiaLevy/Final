﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RepoPattern;
using AnotherOne;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace UnitTests
{
    [TestClass]
    public class UnitTest2
    {
      
        
    }
}
